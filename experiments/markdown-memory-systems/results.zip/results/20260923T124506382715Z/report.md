# Progressive Disclosure Eval Report

## Overall

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| all | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| all | 25.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 687±779 | 123±141 | 0.9% |

## Reproducibility

- Dataset fingerprints: be8a68311daab834b73d2de8e816375f778b5126a4699a61c6f28df0027ec1cf, c22ff1d8fa981a4cac26e92c8f2d45de60fb7df29d9db458e3d1af746d5411ae
- Corpus fingerprints: b5839cbed3424ff9e59ad5fb2b089b83764c2069c464ac5a15c7dfef85da6242, ba849c1b291628c816ec5897d62fb90fe838c2882e272ce748b6dcde77f0709b
- Prompt fingerprints: f103160732c9cae71f0fc964e9aa3a0154069a26573f202bdb6fd6ad744029d9
- **Warning:** results contain multiple dataset versions/content fingerprints.
- **Warning:** results contain multiple corpus content fingerprints.

## By corpus

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| northstar | 6 | 4 | 2 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| tell-aster | 6 | 4 | 2 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| northstar | 0.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 428±428 | 172±172 | 1.1% |
| tell-aster | 50.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 946±946 | 74±74 | 0.7% |

## Prompt × model comparison

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano :: local-rag-answer-system@v1#f1031607 | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano :: local-rag-answer-system@v1#f1031607 | 25.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 687±779 | 123±141 | 0.9% |

## By prompt

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local-rag-answer-system@v1#f1031607 | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

## By model

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

## By repeat

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

## By tag

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| approval | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| billing | 6 | 4 | 2 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| commercial | 6 | 4 | 2 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| excavation | 6 | 4 | 2 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |
| outage | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| single_doc | 12 | 8 | 4 | 66.7% | 16.7% | 25.0% | 25.0% | 25.0% | 25.0% | 75.0% | 100.0% |

## Hardest cases

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| EVAL-002 | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| TA-S-001 | 3 | 2 | 1 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |
| TA-S-002 | 3 | 2 | 1 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |

### Hardest-case efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 0.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 428±428 | 178±178 | 1.1% |
| EVAL-002 | 0.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 428±428 | 165±165 | 1.1% |
| TA-S-001 | 50.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 946±946 | 80±80 | 0.7% |
| TA-S-002 | 50.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 946±946 | 68±68 | 0.7% |

## Run-to-run variable cases

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| EVAL-002 | 3 | 2 | 1 | 66.7% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 50.0% | — |
| TA-S-001 | 3 | 2 | 1 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |
| TA-S-002 | 3 | 2 | 1 | 66.7% | 33.3% | 50.0% | 50.0% | 50.0% | 50.0% | 100.0% | 100.0% |

### Variable-case efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 0.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 428±428 | 178±178 | 1.1% |
| EVAL-002 | 0.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 428±428 | 165±165 | 1.1% |
| TA-S-001 | 50.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 946±946 | 80±80 | 0.7% |
| TA-S-002 | 50.0% | 0.50±0.50 | 0.50 | 1.00 | 0.50±0.50 | 946±946 | 68±68 | 0.7% |

## Per-document discovery coverage

| Required document | Trials | Discovery | First-read hit | Stop after evidence | Doc precision | Mean docs |
| --- | --- | --- | --- | --- | --- | --- |
| TA-EXC-01 | 3 | 50.0% | 100.0% | 100.0% | 50.0% | 0.50 |
| TA-EXC-02 | 3 | 50.0% | 100.0% | 100.0% | 50.0% | 0.50 |
| commercial.billing.credits.migration | 3 | 0.0% | 50.0% | — | 0.0% | 0.50 |
| commercial.billing.credits.outage | 3 | 0.0% | 50.0% | — | 0.0% | 0.50 |

## Execution errors

| Error type | Count |
| --- | --- |
| RuntimeError | 4 |
