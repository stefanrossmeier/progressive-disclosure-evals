# Progressive Disclosure Eval Report

## Overall

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| all | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| all | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 5821±2313 | 172±47 | 11.3% |

## Reproducibility

- Dataset fingerprints: be8a68311daab834b73d2de8e816375f778b5126a4699a61c6f28df0027ec1cf, c22ff1d8fa981a4cac26e92c8f2d45de60fb7df29d9db458e3d1af746d5411ae
- Corpus fingerprints: b5839cbed3424ff9e59ad5fb2b089b83764c2069c464ac5a15c7dfef85da6242, ba849c1b291628c816ec5897d62fb90fe838c2882e272ce748b6dcde77f0709b
- Prompt fingerprints: f103160732c9cae71f0fc964e9aa3a0154069a26573f202bdb6fd6ad744029d9
- **Warning:** results contain multiple dataset versions/content fingerprints.
- **Warning:** results contain multiple corpus content fingerprints.

## By corpus

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| northstar | 2 | 2 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| tell-aster | 2 | 2 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| northstar | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 3515±41 | 158±14 | 15.6% |
| tell-aster | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 8127±243 | 187±62 | 7.0% |

## Prompt × model comparison

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano :: local-rag-answer-system@v1#f1031607 | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

### Efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano :: local-rag-answer-system@v1#f1031607 | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 5821±2313 | 172±47 | 11.3% |

## By prompt

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| local-rag-answer-system@v1#f1031607 | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

## By model

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| gpt-5-nano | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

## By repeat

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

## By tag

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| approval | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| billing | 2 | 2 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| commercial | 2 | 2 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| excavation | 2 | 2 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| outage | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| single_doc | 4 | 4 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

## Hardest cases

| Group | Trials | Completed | Errors | Completion | E2E success | Task success | Discovery | Answer | Attribution | First-read hit | Stop after evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| EVAL-002 | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| TA-S-001 | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |
| TA-S-002 | 1 | 1 | 0 | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 100.0% | 0.0% |

### Hardest-case efficiency

| Group | Doc precision | Docs μ±σ | Docs median | Docs p95 | Calls μ±σ | Input tok μ±σ | Output tok μ±σ | Knowledge loaded |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EVAL-001 | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 3474±0 | 172±0 | 15.5% |
| EVAL-002 | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 3556±0 | 143±0 | 15.7% |
| TA-S-001 | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 7884±0 | 249±0 | 6.8% |
| TA-S-002 | 16.7% | 6.00±0.00 | 6.00 | 6.00 | 1.00±0.00 | 8370±0 | 125±0 | 7.3% |

## Run-to-run variable cases

No case showed mixed quality/stopping outcomes or variable document-read counts across repeated runs.

## Per-document discovery coverage

| Required document | Trials | Discovery | First-read hit | Stop after evidence | Doc precision | Mean docs |
| --- | --- | --- | --- | --- | --- | --- |
| TA-EXC-01 | 1 | 100.0% | 100.0% | 0.0% | 16.7% | 6.00 |
| TA-EXC-02 | 1 | 100.0% | 100.0% | 0.0% | 16.7% | 6.00 |
| commercial.billing.credits.migration | 1 | 100.0% | 100.0% | 0.0% | 16.7% | 6.00 |
| commercial.billing.credits.outage | 1 | 100.0% | 100.0% | 0.0% | 16.7% | 6.00 |

## Execution errors

No execution errors were recorded.
